package com.example.recyclerviewdemo

import android.annotation.SuppressLint
import android.content.Intent
import android.content.IntentSender
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.compose.material3.Snackbar
import androidx.core.app.ActivityCompat
import com.example.recyclerviewdemo.databinding.ActivityLocationDemoBinding
import com.google.android.gms.common.api.ResolvableApiException
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.LocationSettingsRequest
import com.google.android.gms.location.LocationSettingsStatusCodes
import com.google.android.material.snackbar.Snackbar

class LocationDemoActivity : AppCompatActivity() {

    private lateinit var binding : ActivityLocationDemoBinding
    private lateinit var fusedLocationProviderClient: FusedLocationProviderClient

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityLocationDemoBinding.inflate(layoutInflater)
        setContentView(binding.root)


        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this)


        binding.btnLocation.setOnClickListener {
                getLetLong()
        }
    }

    private fun getLetLong()
    {
        if(ActivityCompat.checkSelfPermission(this,android.Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this,android.Manifest.permission.ACCESS_COARSE_LOCATION)
            != PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(this,
                arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION
                    ,android.Manifest.permission.ACCESS_COARSE_LOCATION)
                ,100)

        }

        val location = fusedLocationProviderClient.lastLocation
        location.addOnSuccessListener {
            if(it != null){
                binding.txtLat.text = it.latitude.toString()
                binding.txtLong.text = it.longitude.toString()


                var a = it.latitude
                var b = it.longitude

                var snackbar = Snackbar.make(binding.root,"Your lat long is Done"
                    ,Snackbar.LENGTH_LONG)
                snackbar.setAction("Open Map", View.OnClickListener {
                    var intent = Intent(Intent.ACTION_VIEW)
                    intent.setData(Uri.parse("geo:"+a+","+b))
                    var selectIntent = Intent.createChooser(intent,"Launch Map")
                    startActivity(selectIntent)
                })
                snackbar.setTextColor(Color.WHITE)
                snackbar.setActionTextColor(Color.WHITE)
                snackbar.setBackgroundTint(Color.BLACK)
                snackbar.show()

            }
        }

    }

}