package com.example.airline

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.example.airline.databinding.ActivityRegisterBinding

class registerActivity : AppCompatActivity() {
    private lateinit var rbindding : ActivityRegisterBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        rbindding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(rbindding.root)

        rbindding.btnLogin.setOnClickListener {
            startActivity(Intent(this, homeActivity::class.java))
        }

        rbindding.txtLoginNow.setOnClickListener {
            startActivity(Intent(this,loginActivity::class.java))
        }
    }
}
