package com.example.airline

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.example.airline.databinding.ActivityLoginBinding

class loginActivity : AppCompatActivity() {

    private lateinit var lbindding : ActivityLoginBinding
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        lbindding= ActivityLoginBinding.inflate(layoutInflater)
        setContentView(lbindding.root)

        lbindding.btnLogin.setOnClickListener {
            startActivity(Intent(this,homeActivity::class.java))
        }
        lbindding.txtForgotPass.setOnClickListener {
            startActivity(Intent(this,forgotActivity::class.java))
        }
        lbindding.txtRegisterNow.setOnClickListener {
            startActivity(Intent(this,registerActivity::class.java))
        }


        }
}