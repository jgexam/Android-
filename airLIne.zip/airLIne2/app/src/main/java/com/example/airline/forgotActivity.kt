package com.example.airline

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.airline.databinding.ActivityForgotBinding

class forgotActivity : AppCompatActivity() {
    private lateinit var fbindding : ActivityForgotBinding
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        fbindding= ActivityForgotBinding.inflate(layoutInflater)
        setContentView(fbindding.root)
    }
}