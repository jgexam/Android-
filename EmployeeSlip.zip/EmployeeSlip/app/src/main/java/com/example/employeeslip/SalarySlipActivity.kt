package com.example.employeeslip

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.employeeslip.databinding.ActivitySalarySlipBinding

class SalarySlipActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySalarySlipBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivitySalarySlipBinding.inflate(layoutInflater)
        setContentView(binding.root)

        var getEmpId = intent.getStringExtra("id")
        var getEmpName = intent.getStringExtra("name")
        var getEmpPost = intent.getStringExtra("post")
        var getEmpSalary = intent.getStringExtra("salary")?.toInt()

        var it = (getEmpSalary!! / 100) * 2.5
        var hra = (getEmpSalary!! / 100) * 1

        var basicSalary = getEmpSalary - it - hra

        binding.txtEmpId.text = "Employee Id: "+getEmpId
        binding.txtEmpName.text = "Employee Name: "+getEmpName
        binding.txtEmpDesignation.text = "Employee Post: "+getEmpPost
        binding.txtEmpBaseSalary.text = "Basic Salary: "+basicSalary.toString()
    }
}