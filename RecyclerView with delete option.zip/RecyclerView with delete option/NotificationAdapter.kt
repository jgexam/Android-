package com.example.recyclerviewdemo

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.ViewHolder

class NotificationAdapter(var context: Context):RecyclerView.Adapter<NotificationAdapter.MyHolder>() {

    var objList : ArrayList<NotificationData> = ArrayList()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyHolder {
       var myView = LayoutInflater.from(parent.context).inflate(R.layout.raw_notification,parent,false)
        return MyHolder(myView)
    }

    override fun getItemCount(): Int {
       return objList.size
    }

    override fun onBindViewHolder(holder: MyHolder, position: Int) {
       holder.title.text = objList[position].title
       holder.time.text = objList[position].time
       holder.subTitle.text = objList[position].subTitle

       holder.btnDelete.tag = position
       holder.btnDelete.setOnClickListener {
           objList.removeAt(position)
           Toast.makeText(context,"Deleted successfully...!",Toast.LENGTH_SHORT).show()
           notifyDataSetChanged()
       }
    }

    class MyHolder(itemView: View): ViewHolder(itemView){

        var title = itemView.findViewById<TextView>(R.id.txtTitle)!!
        var time = itemView.findViewById<TextView>(R.id.txtTime)!!
        var subTitle = itemView.findViewById<TextView>(R.id.txtSubTitle)!!
        var btnDelete = itemView.findViewById<ImageView>(R.id.btnDelete)!!

    }
}