package com.example.recyclerviewdemo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.recyclerviewdemo.databinding.ActivityNotificationBinding

class NotificationActivity : AppCompatActivity() {

    private lateinit var binding  : ActivityNotificationBinding
    private lateinit var notificationAdapter : NotificationAdapter


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityNotificationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        notificationAdapter = NotificationAdapter(this)
        binding.rvNotification.layoutManager = LinearLayoutManager(this,RecyclerView.VERTICAL,false)
        binding.rvNotification.adapter = notificationAdapter

        setData()
    }

    private fun setData()
    {

        var model = NotificationData("WhatsApp","10:00 AM",
            "This is notification From WhatsApp Application")
        notificationAdapter.objList.add(model)

        model = NotificationData("Facebook","12:00 AM",
            "This is notification From Facebook Application")
        notificationAdapter.objList.add(model)

        model = NotificationData("Instagram","01:00 PM",
            "This is notification From Instagram Application")
        notificationAdapter.objList.add(model)

        model = NotificationData("WhatsApp","10:00 AM",
            "This is notification From WhatsApp Application")
        notificationAdapter.objList.add(model)

        model = NotificationData("Facebook","12:00 AM",
            "This is notification From Facebook Application")
        notificationAdapter.objList.add(model)

        model = NotificationData("Instagram","01:00 PM",
            "This is notification From Instagram Application")
        notificationAdapter.objList.add(model)

        model = NotificationData("Facebook","12:00 AM",
            "This is notification From Facebook Application")
        notificationAdapter.objList.add(model)

        model = NotificationData("Instagram","01:00 PM",
            "This is notification From Instagram Application")
        notificationAdapter.objList.add(model)

        model = NotificationData("WhatsApp","10:00 AM",
            "This is notification From WhatsApp Application")
        notificationAdapter.objList.add(model)

        model = NotificationData("Facebook","12:00 AM",
            "This is notification From Facebook Application")
        notificationAdapter.objList.add(model)

        model = NotificationData("Instagram","01:00 PM",
            "This is notification From Instagram Application")
        notificationAdapter.objList.add(model)

    }
}