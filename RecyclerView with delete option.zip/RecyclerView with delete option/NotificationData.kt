package com.example.recyclerviewdemo

data class NotificationData(var title : String, var time : String, var subTitle : String)
