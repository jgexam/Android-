package com.example.recyclerviewdemo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.recyclerviewdemo.databinding.ActivityUserDetailsBinding

class UserDetailsActivity : AppCompatActivity() {

    private lateinit var uBinding : ActivityUserDetailsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        uBinding = ActivityUserDetailsBinding.inflate(layoutInflater)
        setContentView(uBinding.root)

        uBinding.txtFname.text = intent.getStringExtra("NAME")
        uBinding.txtTime.text = intent.getStringExtra("TIME")
        uBinding.txtMsg.text = intent.getStringExtra("MSG")

    }
}