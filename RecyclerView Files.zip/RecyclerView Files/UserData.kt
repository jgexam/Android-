package com.example.recyclerviewdemo

data class UserData(var userName:String,
                    var userMSG:String,
                    var msgTime:String,
                    var state : Int)
