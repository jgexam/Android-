package com.example.recyclerviewdemo

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.ViewHolder


class UserAdapter(var context: Context):RecyclerView.Adapter<UserAdapter.MyHolder>() {

    var userList : ArrayList<UserData> = ArrayList()


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyHolder {

        var myView = LayoutInflater.from(parent.context).inflate(R.layout.raw_user_chat,parent,false)

        return MyHolder(myView)
    }

    override fun getItemCount(): Int {
        return userList.size
    }

    override fun onBindViewHolder(holder: MyHolder, position: Int) {

        holder.uName.text = userList[position].userName
        holder.time.text = userList[position].msgTime
        holder.msg.text = userList[position].userMSG

        when (userList[position].state) {
            2 -> {
                holder.imgMsg.setImageResource(R.drawable.sent)
            }
            3 -> {
                holder.imgMsg.setImageResource(R.drawable.double_check)
            }
            else -> {
                holder.imgMsg.setImageResource(R.drawable.check)
            }
        }

        holder.mainView.tag = position
        holder.mainView.setOnClickListener {
            context.startActivity(Intent(context,UserDetailsActivity::class.java)
                .putExtra("NAME",userList[position].userName)
                .putExtra("TIME",userList[position].msgTime)
                .putExtra("MSG",userList[position].userMSG))
        }

    }

    class MyHolder(itemview : View):ViewHolder(itemview){
        var uName = itemview.findViewById<TextView>(R.id.txtUname)
        var time = itemview.findViewById<TextView>(R.id.txtTime)
        var msg = itemview.findViewById<TextView>(R.id.txtMsg)
        var imgMsg = itemview.findViewById<ImageView>(R.id.imgMsg)
        var mainView = itemview.findViewById<CardView>(R.id.mainCardView)
    }

}