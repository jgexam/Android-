package com.example.recyclerviewdemo

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.recyclerviewdemo.databinding.ActivityHomeBinding


class HomeActivity : AppCompatActivity(){

    private lateinit var binding : ActivityHomeBinding

    lateinit var userAdapter : UserAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        userAdapter = UserAdapter(this)
     //   binding.rvUserList.layoutManager = LinearLayoutManager(this, RecyclerView.VERTICAL, false)
        binding.rvUserList.layoutManager = GridLayoutManager(this,1)
        binding.rvUserList.adapter = userAdapter
        addData()

        binding.txtDataNO.text = "Your Data : " + userAdapter.userList.size

    }

    private fun addData()
    {
        userAdapter.userList = ArrayList()

        var model = UserData("Shivani","Hello Team","10:00AM",1)
        userAdapter.userList.add(model)

        model = UserData("Dhruvi","Hello Friends","08:00AM",2)
        userAdapter.userList.add(model)

        model = UserData("Aesha","Hello Good Morning","09:00AM",3)
        userAdapter.userList.add(model)
        model = UserData("Dhruvi","Hello Friends","08:00AM",2)
        userAdapter.userList.add(model)

        model = UserData("Aesha","Hello Good Morning","09:00AM",3)
        userAdapter.userList.add(model)
        model = UserData("Dhruvi","Hello Friends","08:00AM",2)
        userAdapter.userList.add(model)

        model = UserData("Aesha","Hello Good Morning","09:00AM",3)
        userAdapter.userList.add(model)
        model = UserData("Dhruvi","Hello Friends","08:00AM",2)
        userAdapter.userList.add(model)

        model = UserData("Aesha","Hello Good Morning","09:00AM",3)
        userAdapter.userList.add(model)
        model = UserData("Dhruvi","Hello Friends","08:00AM",2)
        userAdapter.userList.add(model)

        model = UserData("Aesha","Hello Good Morning","09:00AM",3)
        userAdapter.userList.add(model)
        model = UserData("Dhruvi","Hello Friends","08:00AM",2)
        userAdapter.userList.add(model)

        model = UserData("Aesha","Hello Good Morning","09:00AM",3)
        userAdapter.userList.add(model)
        model = UserData("Dhruvi","Hello Friends","08:00AM",2)
        userAdapter.userList.add(model)

        model = UserData("Aesha","Hello Good Morning","09:00AM",3)
        userAdapter.userList.add(model)
        model = UserData("Aesha","Hello Good Morning","09:00AM",3)
        userAdapter.userList.add(model)
        model = UserData("Dhruvi","Hello Friends","08:00AM",2)
        userAdapter.userList.add(model)

        model = UserData("Aesha","Hello Good Morning","09:00AM",3)
        userAdapter.userList.add(model)
        model = UserData("Aesha","Hello Good Morning","09:00AM",3)
        userAdapter.userList.add(model)
        model = UserData("Dhruvi","Hello Friends","08:00AM",2)
        userAdapter.userList.add(model)

        model = UserData("Aesha","Hello Good Morning","09:00AM",3)
        userAdapter.userList.add(model)
        model = UserData("Aesha","Hello Good Morning","09:00AM",3)
        userAdapter.userList.add(model)
        model = UserData("Dhruvi","Hello Friends","08:00AM",2)
        userAdapter.userList.add(model)

        model = UserData("Aesha","Hello Good Morning","09:00AM",3)
        userAdapter.userList.add(model)
        model = UserData("Aesha","Hello Good Morning","09:00AM",3)
        userAdapter.userList.add(model)
        model = UserData("Dhruvi","Hello Friends","08:00AM",2)
        userAdapter.userList.add(model)

        model = UserData("Aesha","Hello Good Morning","09:00AM",3)
        userAdapter.userList.add(model)
        model = UserData("Aesha","Hello Good Morning","09:00AM",3)
        userAdapter.userList.add(model)
        model = UserData("Dhruvi","Hello Friends","08:00AM",2)
        userAdapter.userList.add(model)

        model = UserData("Aesha","Hello Good Morning","09:00AM",3)
        userAdapter.userList.add(model)
        model = UserData("Aesha","Hello Good Morning","09:00AM",3)
        userAdapter.userList.add(model)
        model = UserData("Dhruvi","Hello Friends","08:00AM",2)
        userAdapter.userList.add(model)

        model = UserData("Aesha","Hello Good Morning","09:00AM",3)
        userAdapter.userList.add(model)
        model = UserData("Aesha","Hello Good Morning","09:00AM",3)
        userAdapter.userList.add(model)
        model = UserData("Dhruvi","Hello Friends","08:00AM",2)
        userAdapter.userList.add(model)

        model = UserData("Aesha","Hello Good Morning","09:00AM",3)
        userAdapter.userList.add(model)
    }
}