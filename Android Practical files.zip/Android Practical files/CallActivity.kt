package com.example.mcaapplication

import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.AdapterView.OnItemClickListener
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.view.get
import com.example.mcaapplication.databinding.ActivityCallBinding

class CallActivity : AppCompatActivity() {

    private lateinit var cBinding : ActivityCallBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        cBinding = ActivityCallBinding.inflate(layoutInflater)
        setContentView(cBinding.root)

        var listAdapter = ArrayAdapter(this,android.R.layout.simple_list_item_1,resources.getStringArray(R.array.subject))

        cBinding.listView.adapter = listAdapter

        cBinding.listView.onItemClickListener = object : OnItemClickListener{
            override fun onItemClick(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {


//
             var itemData = cBinding.listView.getItemAtPosition(position) as String

                dialogShow(itemData)
//
//                var itemID = cBinding.listView.getItemIdAtPosition(position)
//
//                Toast.makeText(this@CallActivity,itemID.toString(),Toast.LENGTH_SHORT).show()
//
//                startActivity(Intent(this@CallActivity,
//                    HomeActivity::class.java).putExtra("DATA",itemData))

            }
        }
    }

    fun dialogShow(name:String)
    {
        var builder = AlertDialog.Builder(this)
        builder.setTitle(name)
        builder.setMessage("Are you sure you want to Exit from this App?")
        builder.setIcon(R.drawable.email)

        builder.setPositiveButton("Yes",DialogInterface.OnClickListener { dialog, which ->
            Toast.makeText(this,"This is Positive Button",Toast.LENGTH_LONG).show()
        })

        builder.setNegativeButton("NO",DialogInterface.OnClickListener { dialog, which ->
            Toast.makeText(this,"This is Cancellation Button",Toast.LENGTH_LONG).show()
        })


        var alertShow : AlertDialog = builder.create()
        alertShow.setCancelable(false)
        alertShow.show()

    }


}

