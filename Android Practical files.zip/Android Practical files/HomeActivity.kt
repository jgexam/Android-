package com.example.mcaapplication

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import com.example.mcaapplication.databinding.ActivityHomeBinding

class HomeActivity : AppCompatActivity() {

    private lateinit var binding : ActivityHomeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

//        binding.txtEmail.text = intent.getStringExtra("EMAIL")
//        binding.txtPass.text = intent.getStringExtra("PASS")

        binding.txtEmail.text = intent.getStringExtra("DATA")

        var intentData  = intent.getStringExtra("DATA")

        Log.d("TAG>>>>>>>>>>>>>>>>>>", intent.getStringExtra("DATA").toString())

        if(intentData == "Android")
        {
            binding.btnIOS.visibility = View.INVISIBLE
            binding.btnFlutter.visibility = View.INVISIBLE
            binding.btnAngular.visibility = View.INVISIBLE
            binding.btnCS.visibility = View.INVISIBLE
            binding.btnDC.visibility = View.INVISIBLE
        }
        else if(intentData == "ios")
        {
            binding.btnAndroid.visibility = View.INVISIBLE
            binding.btnFlutter.visibility = View.INVISIBLE
            binding.btnAngular.visibility = View.INVISIBLE
            binding.btnCS.visibility = View.INVISIBLE
            binding.btnDC.visibility = View.INVISIBLE
        }

        binding.txtlogout.setOnClickListener {
            var sharedPref : SharedPreferences = this.getSharedPreferences("MYPREFFILE", MODE_PRIVATE)
            var edits : SharedPreferences.Editor =  sharedPref.edit()

            edits.clear()
            edits.commit()

            startActivity(Intent(this,LoginActivity::class.java))
            finishAffinity()
        }

    }
}