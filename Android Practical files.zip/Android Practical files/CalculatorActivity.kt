package com.example.mcaapplication

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import com.example.mcaapplication.databinding.ActivityCalculatorBinding

class CalculatorActivity : AppCompatActivity() {

    private lateinit var binding : ActivityCalculatorBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityCalculatorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnPlus.setOnClickListener {

            binding.txtAns.text = ""

            if(binding.edtNo1.text.toString().trim().isNotEmpty() && binding.edtNo2.text.toString().trim().isNotEmpty())
            {
                Toast.makeText(this,(binding.edtNo1.text.toString().toInt() +
                        binding.edtNo2.text.toString().toInt()).toString(),Toast.LENGTH_LONG).show()

                binding.txtAns.text = (binding.edtNo1.text.toString().toInt() + binding.edtNo2.text.toString().toInt()).toString()

            }
            else{
                Toast.makeText(this,"please enter value",Toast.LENGTH_LONG).show()
            }

        }
    }
}