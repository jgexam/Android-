package com.example.mcaapplication

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Intent
import android.graphics.drawable.Icon
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.service.chooser.ChooserAction
import android.widget.Toast
import com.example.mcaapplication.databinding.ActivityForgotPasswordBinding

class ForgotPasswordActivity : AppCompatActivity() {

    private lateinit var fBinding : ActivityForgotPasswordBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        fBinding = ActivityForgotPasswordBinding.inflate(layoutInflater)
        setContentView(fBinding.root)


        fBinding.btnSendLink.setOnClickListener {
            if(fBinding.edtEmail.text.toString().trim().isEmpty())
            {
                Toast.makeText(this,"Please enter email...!",Toast.LENGTH_SHORT).show()
            }else{
                val intent = Intent(Intent.ACTION_SENDTO, Uri.fromParts("mailto","test@gmail.com",null))
                startActivity(Intent.createChooser(intent,"Hello"))
            }


        }
    }
}